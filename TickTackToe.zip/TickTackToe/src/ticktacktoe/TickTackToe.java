/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ticktacktoe;
//********************************************************************************
// STUDENT NAME:  [Your Name]
// FIU EMAIL: [Your FIU email]
// CLASS: COP 2210 – [Semester Year]
// ASSIGNMENT # [#]
// DATE: [Date]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else, except as outlined in the 
// assignment instructions.
//********************************************************************************

import javax.swing.JOptionPane;

/**
 *
 * @author Rahshann
 */
public class TickTackToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String userName;
        String userName2;

        Object[] XO = {"X", "O"};

        JOptionPane.showMessageDialog(null, "IT'S TIME TO PLAY SOME TIC-TAC-TOE ", "Tic-Tac-Toe",
                JOptionPane.INFORMATION_MESSAGE);

        userName = JOptionPane.showInputDialog("Player 1 enter your name:");
        userName2 = JOptionPane.showInputDialog("Player 2 enter your name:");
        String xoChoice = (String) JOptionPane.showInputDialog(null, "Player 1 would you like to be X or O?",
                "TIC-TAC-TOE", JOptionPane.INFORMATION_MESSAGE, null, XO, "X");
        if (xoChoice.equals("X")) {
            JOptionPane.showMessageDialog(null, (userName) +  ": you are X" + "\n" + (userName2) + ": you are 0", "Tic-Tac-Toe", JOptionPane.INFORMATION_MESSAGE,null);
         }
        if(xoChoice.equals("O")){
            JOptionPane.showMessageDialog(null, (userName) +  ": you are O" + "\n" + (userName2) + ": you are X", "Tic-Tac-Toe", JOptionPane.INFORMATION_MESSAGE,null);
        }
        
        
     TheGame TTTGame = new TheGame();
        TTTGame.getClass();// TODO code application logic here
        
    }

}
