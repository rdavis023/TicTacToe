/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticktacktoe;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Rahshann
 */
public class TheGame implements ActionListener {
    
    Random Rand = new Random();
    JFrame frame = new JFrame();
    JPanel title_panel = new JPanel();
    JPanel button_panel = new JPanel();
    JLabel textfield = new JLabel();
    JButton [][] buttons = new JButton [3][3];
    boolean player1_turn;
    
    
    
    TheGame(){
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,800);
        frame.getContentPane().setBackground(new Color(50,50,50));
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);
        
        textfield.setBackground(new Color(25,25,25));
        textfield.setForeground(new Color(25,255,0));
        textfield.setFont(new Font("Ink Free",Font.BOLD,75));
        textfield.setHorizontalAlignment(JLabel.CENTER);
        textfield.setText("Tick-Tack-Toe");
        textfield.setOpaque(true);
        
        title_panel.setLayout(new BorderLayout());
        title_panel.setBounds(0,0,800,100);
        
        button_panel.setLayout(new GridLayout(3,3));
        button_panel.setBackground(Color.BLACK);
        
        for (JButton[] button : buttons) {
            for (int j = 0; j < button.length; j++) {
                button[j] = new JButton();
                button_panel.add(button[j]);
                button[j].setFont(new Font("Times New Roman",Font.BOLD,120));
                button[j].setFocusable(false);
                button[j].addActionListener(this);
            }
        }
        
        title_panel.add(textfield);
        frame.add(title_panel,BorderLayout.NORTH);
        frame.add(button_panel);
        
        firstTurn();
        
    }

    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        
        for (JButton[] button1 : buttons) {
            for (JButton button : button1) {
                if (e.getSource() == button) {
                    if (player1_turn) {
                        if (button.getText() == "") {
                            button.setForeground(Color.BLACK);
                            button.setText("X");
                            player1_turn = false;
                            textfield.setText("O turn");
                            checkWinner();
                        }
                    } else {
                        if (button.getText() == "") {
                            button.setForeground(Color.RED);
                            button.setText("O");
                            player1_turn = true;
                            textfield.setText("X turn");
                            checkWinner();
                        }
                    }
                }
            }
        }
    }
    
    public void firstTurn(){
        try {
            Thread.sleep(2500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        if(Rand.nextInt(2)==0){
           player1_turn = true;
           textfield.setText("X turn");
        }
        else {
           player1_turn = false;
           textfield.setText("O turn");
        }
    }
    
    public void checkWinner(){
        if((buttons[0][0].getText()== "X")&& (buttons[1][0].getText()== "X") && 
                (buttons[2][0].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][0].getText()== "X")&& (buttons[0][1].getText()== "X") && 
           (buttons[0][2].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][1].getText()== "X")&& (buttons[1][1].getText()== "X") && 
           (buttons[2][1].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][2].getText()== "X")&& (buttons[1][2].getText()== "X") && 
          (buttons[2][2].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][0].getText()== "X")&& (buttons[1][1].getText()== "X") && 
            (buttons[2][2].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][2].getText()== "X")&& (buttons[1][1].getText()== "X") && 
            (buttons[2][0].getText()== "X")){
            xWins(0,1,2);
        }
        if((buttons[0][1].getText()== "X")&& (buttons[1][1].getText()== "X") && 
            (buttons[1][2].getText()== "X")){
            xWins(0,1,2);
        }
         if((buttons[2][0].getText()== "X")&& (buttons[2][1].getText()== "X") && 
            (buttons[2][2].getText()== "X")){
            xWins(2,2,2);
        }
         if((buttons[1][0].getText()== "X")&& (buttons[1][1].getText()== "X") && 
            (buttons[1][2].getText()== "X")){
            xWins(1,1,1);
        }
        
        
        
        
        
        
       if((buttons[0][0].getText()== "O")&& (buttons[1][0].getText()== "O") && 
                (buttons[2][0].getText()== "O")){
            oWins(0,1,2);
        }
        if((buttons[0][0].getText()== "O")&& (buttons[0][1].getText()== "O") && 
           (buttons[0][2].getText()== "O")){
            oWins(0,1,2);
        }
        if((buttons[0][1].getText()== "O")&& (buttons[1][1].getText()== "O") && 
           (buttons[2][1].getText()== "O")){
            oWins(0,1,2);
        }
        if((buttons[0][2].getText()== "O")&& (buttons[1][2].getText()== "O") && 
          (buttons[2][2].getText()== "O")){
            oWins(0,1,2);
        }
        if((buttons[2][0].getText()== "O")&& (buttons[2][1].getText()== "O") && 
            (buttons[2][2].getText()== "O")){
            oWins(2,2,2);
        }
        if((buttons[0][2].getText()== "O")&& (buttons[1][1].getText()== "O") && 
            (buttons[2][0].getText()== "O")){
            oWins(0,1,2);
        }
        if((buttons[0][1].getText()== "O")&& (buttons[1][1].getText()== "O") && 
            (buttons[1][2].getText()== "O")){
            oWins(0,1,2);
        }
         if((buttons[1][0].getText()== "O")&& (buttons[1][1].getText()== "O") && 
            (buttons[1][2].getText()== "O")){
            oWins(1,1,1);
        }
         if((buttons[0][0].getText()== "O")&& (buttons[1][1].getText()== "O") && 
            (buttons[2][2].getText()== "O")){
            oWins(0,1,2);
        }
        
        
            
    }
    
    public void xWins(int a, int b, int c){
       
        buttons[a][b].setBackground(Color.GREEN);
        
        buttons[a][a].setBackground(Color.GREEN);
        buttons[b][b].setBackground(Color.GREEN);
        
        buttons[b][a].setBackground(Color.GREEN);
        
        
        for (JButton[] button1 : buttons) {
            for (javax.swing.JButton button : button1) {
                button.setEnabled(false);
            }
        }
        textfield.setText("X wins!");
        JOptionPane.showInputDialog("Would you like to play again? Yes or No.");
    }
    
    public void oWins(int a, int b, int c){
        buttons[a][b].setBackground(Color.GREEN);
        buttons[a][c].setBackground(Color.GREEN);
        buttons[a][a].setBackground(Color.GREEN);
        buttons[b][b].setBackground(Color.GREEN);
        buttons[b][c].setBackground(Color.GREEN);
        buttons[b][a].setBackground(Color.GREEN);
        buttons[c][b].setBackground(Color.GREEN);
        buttons[c][c].setBackground(Color.GREEN);
        buttons[c][a].setBackground(Color.GREEN);
        
        
        for (JButton[] button : buttons) {
            for (JButton button1 : button) {
                button1.setEnabled(false);
            }
        }
        textfield.setText("O wins!");
        JOptionPane.showInputDialog("Would you like to play again? Yes or No.");
    }
}
